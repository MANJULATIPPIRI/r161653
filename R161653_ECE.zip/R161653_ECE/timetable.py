class=input('enter the class from 6 to 10:')
if(class>5 & class<11):
	if(class==6):
		timetable=open('6thclass.pdf','r')
		output.write('timetable')
	elseif(class==7):
		timetable=open('7thclass.pdf','r')
		output.write('timetable')
	if(class==8):
		timetable=open('8thclass.pdf','r')
		output.write('timetable')
	if(class==9):
		timetable=open('9thclass.pdf','r')
		output.write('timetable')
	if(class==10):
		timetable=open('10thclass.pdf','r')
		output.write('timetable')
else:
	print("enter the valid class number")
