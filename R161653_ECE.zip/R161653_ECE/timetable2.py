from tabulate import tabulate
c=input("enter the class from 6 to 10:")
output=open('output.txt','w')
if(c>5 & c<8):
	if(c==6):
		print(tabulate([['time','08AM','09AM','10AM','11AM','12PM','01PM','02PM','03PM','04PM'],['MONDAY','/t','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI'],['tuesday','/t','/t','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI'],['wednesday','/t','/t','/t','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI'],['thusday','/t','/t','/t','/t','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI'],['friday','hindi','/t','/t','/t','/t','MATHS','SCIENCE','ENGLISH','KANNADA'],['saturday','kannada','hindi','/t','/t','/t','/t','MATHS','SCIENCE','ENGLISH']
	else:
		print(tabulate([['time','08AM','09AM','10AM','11AM','12PM','01PM','02PM','03PM','04PM'],['MONDAY','/t/t','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI'],['tuesday','/t/t/t','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI'],['wednesday','/t/t/t/t','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI'],['thusday','hindi''/t','/t','/t','/t','MATHS','SCIENCE','ENGLISH','KANNADA'],['friday','kannada','hindi','/t','/t','/t','/t','MATHS','SCIENCE','ENGLISH']['saturday','ENGLISH','KANNADA','hindi','/t','/t','/t','/t','MATHS','SCIENCE']
if(c>7 & c<10):
	if(c==8):
		print(tabulate([['time','08AM','09AM','10AM','11AM','12PM','01PM','02PM','03PM','04PM'],['monday','/t/t/t','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI'],['tuesday','/t/t/t/t','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI'],['wednesday','hindi''/t','/t','/t','/t','MATHS','SCIENCE','ENGLISH','KANNADA'],['thursday','kannada','hindi','/t','/t','/t','/t','MATHS','SCIENCE','ENGLISH']['friday','ENGLISH','KANNADA','hindi','/t','/t','/t','/t','MATHS','SCIENCE'],['saturday','SCIENCE','ENGLISH','KANNADA','HINDI','/t/t/t/t','MATHS']
	else:
		print(tabulate([['time','08AM','09AM','10AM','11AM','12PM','01PM','02PM','03PM','04PM'],['monday','/t/t/t/t','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI'],['tuesesday','hindi''/t','/t','/t','/t','MATHS','SCIENCE','ENGLISH','KANNADA'],['wednesday','kannada','hindi','/t','/t','/t','/t','MATHS','SCIENCE','ENGLISH']['thursday','ENGLISH','KANNADA','hindi','/t','/t','/t','/t','MATHS','SCIENCE'],['friday','SCIENCE','ENGLISH','KANNADA','HINDI','/t/t/t/t','MATHS'],['saturday','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI']
if(c>9 & c<11):
	if(c==10):
		['monday','hindi''/t','/t','/t','/t','MATHS','SCIENCE','ENGLISH','KANNADA'],['tuesday','kannada','hindi','/t','/t','/t','/t','MATHS','SCIENCE','ENGLISH']['wednesday','ENGLISH','KANNADA','hindi','/t','/t','/t','/t','MATHS','SCIENCE'],['thursday','SCIENCE','ENGLISH','KANNADA','HINDI','/t/t/t/t','MATHS'],['friday','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI'],['friday','/t','MATHS','SCIENCE','ENGLISH','KANNADA','HINDI']
else:
	print("enter the valid class number")
